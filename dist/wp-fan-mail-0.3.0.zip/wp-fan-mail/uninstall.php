<?php
/**
 * iHelp247 WP Fan Mail — uninstall cleanup.
 * © ULXI — UnLimited eXchange, Inc. · published under the iHelp247 brand · GPL-2.0-or-later
 * Deletes all plugin options and the scheduled sweep. The message and contact
 * tables are the SITE OWNER'S data: they are only dropped when the owner has
 * explicitly ticked "Also delete all messages and contacts when the plugin is
 * uninstalled" on the settings page. Off by default — data outlives the plugin.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$ih247_delete_data = (bool) get_option( 'ihelp247_wp_fan_mail_delete_data', false );

foreach ( array( 'forms', 'carrier', 'sendgrid_key', 'from_name', 'from_email', 'store_ip', 'default_cc', 'retention', 'hide_credit', 'delete_data', 'db_version' ) as $ih247_key ) {
	delete_option( 'ihelp247_wp_fan_mail_' . $ih247_key );
}
delete_transient( 'ih247_wpfm_gh_release' );
wp_clear_scheduled_hook( 'ih247_wpfm_daily_maintenance' );

if ( $ih247_delete_data ) {
	global $wpdb;
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ih247_fanmail_messages' ); // phpcs:ignore WordPress.DB.PreparedSQL,WordPress.DB.DirectDatabaseQuery
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'ih247_fanmail_contacts' ); // phpcs:ignore WordPress.DB.PreparedSQL,WordPress.DB.DirectDatabaseQuery
}
